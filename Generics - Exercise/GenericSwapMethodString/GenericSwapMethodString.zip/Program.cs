﻿using System;
using System.Collections.Generic;

namespace GenericSwapMethodString
{
    public class Program
    {
        static void Main(string[] args)
        {
            var items = new List<string>();
            Box<string> box2 = new Box<string>();

            int number = int.Parse(Console.ReadLine());

            for (int i = 0; i < number; i++)
            {
                string input = Console.ReadLine();
                box2 = new Box<string>(input);
                items.Add(input);
            }

            string[] indexes = Console.ReadLine().Split();
            int firstIndex = int.Parse(indexes[0]);
            int secondIndex = int.Parse(indexes[1]);

            items = box2.Swap(items, firstIndex, secondIndex);


            foreach (var item in items)
            {
                Console.WriteLine($"{item.GetType()}: {item}");
            }
        }
    }
}
